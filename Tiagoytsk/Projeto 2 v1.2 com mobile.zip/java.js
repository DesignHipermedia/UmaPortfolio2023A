<script setup>
  import { ref } from "vue";
  function notify() {
    alert('You Have been subscribed to the newsletter.')
  }
</script>